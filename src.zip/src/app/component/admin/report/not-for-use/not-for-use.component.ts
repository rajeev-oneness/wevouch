import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-for-use',
  templateUrl: './not-for-use.component.html',
  styleUrls: ['./not-for-use.component.css']
})
export class NotForUseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
