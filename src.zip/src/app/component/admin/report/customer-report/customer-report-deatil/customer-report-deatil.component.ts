import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-report-deatil',
  templateUrl: './customer-report-deatil.component.html',
  styleUrls: ['./customer-report-deatil.component.css']
})
export class CustomerReportDeatilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
