import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ticket-report-detail',
  templateUrl: './ticket-report-detail.component.html',
  styleUrls: ['./ticket-report-detail.component.css']
})
export class TicketReportDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
