import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-report-detail',
  templateUrl: './product-report-detail.component.html',
  styleUrls: ['./product-report-detail.component.css']
})
export class ProductReportDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
