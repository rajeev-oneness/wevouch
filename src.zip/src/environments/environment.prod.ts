export const environment = {
  production: true,
  dasboardPath: '/admin/#/admin/dashboard',
  projectPath : '/admin/#/login',
  apiUrl : 'http://3.136.213.9:5000/api/',
};
